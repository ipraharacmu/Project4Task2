package ds;
 /**
 * Iprahara
 * Ipsita Praharaj
 * This Java program imports the necessary classes for making HTTP requests,
 * reading user input, and parsing JSON data. It makes use of the Chuck Norris jokes API to retrieve
 * a list of categories of Chuck Norris jokes and allows the user to select a category and get a random joke
 * from that category. It opens an HTTP connection to the API endpoint, reads the response, and parses it as a
 * JSONArray to get the categories. It then prompts the user to enter a category and opens a new HTTP connection
 * to the API endpoint with the selected category. It reads the response
 * and parses it as a JSONObject to get a random joke in the selected category, which is then printed to the console.
 */


/**
 * API used-
 * https://api.chucknorris.io/jokes/categories & https://api.chucknorris.io/jokes/random?category={category} & https://api.chucknorris.io/jokes/search?query={query}
 * API Response-
 * ["animal","career","celebrity","dev","explicit","fashion","food","history","money","movie","music","political","religion","science","sport","travel"]
 * App Idea: Joke Category Selector
 * Description: This app allows users to input a choice if they wish to hear a joke by category or free search of text in a joke DB
 * displays a random joke from that category along with an image related to the input using Flickr API - (https://www.flickr.com/services/api/)
 */


import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.ProtocolException;
import java.net.URL;
import java.util.Scanner;
import org.json.JSONArray;
import org.json.JSONObject;

public class ChuckNorrisJokeCategories {

    /**
     * This function takes in a category string and retrieves a random joke in that category from the Chuck Norris jokes API.
     * It returns the joke as a string.
     */

    static String allCategories() throws IOException {
        // Creating a new URL object for the Chuck Norris jokes API endpoint with the selected category
        URL jokesUrl = new URL("https://api.chucknorris.io/jokes/categories");
        HttpURLConnection jokesConnection = (HttpURLConnection) jokesUrl.openConnection();
        jokesConnection.setRequestMethod("GET");

        // Reading the response from the API endpoint and storing it in a StringBuilder
        BufferedReader in = new BufferedReader(new InputStreamReader(jokesConnection.getInputStream()));
        String inputLine;
        StringBuilder response = new StringBuilder();
        while ((inputLine = in.readLine()) != null) {
            response.append(inputLine);
        }
        in.close();

        JSONArray jsonArray = new JSONArray(response.toString());
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < jsonArray.length(); i++) {
            sb.append(jsonArray.getString(i)).append(",");
        }


        return sb.toString();
    }
    private static String getJokeByCategory(String category) throws IOException {
        // Creating a new URL object for the Chuck Norris jokes API endpoint with the selected category
        URL jokesUrl = new URL("https://api.chucknorris.io/jokes/random?category=" + category);
        HttpURLConnection jokesConnection = (HttpURLConnection) jokesUrl.openConnection();
        jokesConnection.setRequestMethod("GET");

        // Reading the response from the API endpoint and storing it in a StringBuilder
        BufferedReader in = new BufferedReader(new InputStreamReader(jokesConnection.getInputStream()));
        String inputLine;
        StringBuilder response = new StringBuilder();
        while ((inputLine = in.readLine()) != null) {
            response.append(inputLine);
        }
        in.close();

        // Parsing the response as a JSONObject and returning the random joke in the selected category
        JSONObject jsonObject = new JSONObject(response.toString());
        String joke = jsonObject.getString("value");
        return "Random joke in the category '" + category + "':\n" + joke;
    }

    /**
     * This function takes in a keyword string and retrieves a random joke containing that keyword from the Chuck Norris jokes API.
     * It returns the joke as a string.
     */
    public String getJokeByKeyword(String keyword) throws IOException {
        // Validate keyword length
        if (keyword.length() < 3 || keyword.length() > 120) {
            return "Keyword must be between 3 and 120 characters.";
        }

        // Creating a new URL object for the Chuck Norris jokes search API endpoint with the entered keyword
        URL searchUrl = new URL("https://api.chucknorris.io/jokes/search?query=" + keyword);
        HttpURLConnection searchConnection = (HttpURLConnection) searchUrl.openConnection();
        searchConnection.setRequestMethod("GET");

        // Reading the response from the API endpoint and storing it in a StringBuilder
        BufferedReader in = new BufferedReader(new InputStreamReader(searchConnection.getInputStream()));
        String inputLine;
        StringBuilder response = new StringBuilder();
        while ((inputLine = in.readLine()) != null) {
            response.append(inputLine);
        }
        in.close();

        // Parsing the response as a JSONObject and returning a random joke containing the entered keyword
        JSONObject jsonObject = new JSONObject(response.toString());
        JSONArray jsonArray = jsonObject.getJSONArray("result");
        if (jsonArray.length() == 0) {
            return "No jokes found containing the keyword '" + keyword + "'";
        } else {
            int index = (int) (Math.random() * jsonArray.length());
            String joke = jsonArray.getJSONObject(index).getString("value");
            return "Random joke containing the keyword '" + keyword + "':\n" + joke;
        }
    }

}
