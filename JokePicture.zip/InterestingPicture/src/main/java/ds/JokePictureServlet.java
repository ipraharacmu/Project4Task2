//ipsita praharaj
//iprahara
package ds;

import java.io.IOException;
import java.util.*;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import org.json.JSONObject;


@WebServlet(name = "MainServlet",
        urlPatterns = {"/getAnInterestingPicture", "/getDashboard"})
public class JokePictureServlet extends HttpServlet {
    InterestingPictureModel ipm = null; // The "business model" for this app
    ChuckNorrisJokeCategories jk = null; // The "business model" for this app

    // Initiate this servlet by instantiating the model that it will use.
    @Override
    public void init() {
        ipm = new InterestingPictureModel();
        jk = new ChuckNorrisJokeCategories();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException  {

        // get the search parameter if it exists
        String search = request.getParameter("searchWord");
        String path = request.getServletPath();

        String nextView;

        if (path.equals("/getAnInterestingPicture")) {
            if (search != null) {

                // create JSON object containing all the tracked information
                JSONObject object = new JSONObject();
                object.put("Request_endpoint", "/getAnInterestingPicture");
                object.put("Request_searchWord", search);
                object.put("Request_timestamp", new Date().toString());

                // track request and reply to the 3rd party API
                object.put("api_endpoint", "https://api.flickr.com & https://api.chucknorris.io/jokes/");
                String pictureURL = ipm.doFlickrSearch(search, "mobile");
                String joke = jk.getJokeByKeyword(search);
                String categories = jk.allCategories();
                System.out.println("ip"+joke);
                object.put("api_joke", joke);
                object.put("api_categories",categories);
                object.put("api_pic",pictureURL);
                object.put("api_timestamp", new Date().toString());

                // add keys for the API response statuses
                object.put("api_pic_status", "");
                object.put("api_joke_status", "");

                // check the status of the picture API response
                if (pictureURL != null && !pictureURL.isEmpty()) object.put("api_pic_status", "success");
                else object.put("api_pic_status", "failure");

                // check the status of the joke API response
                if (joke != null && !joke.isEmpty()) object.put("api_joke_status", "success");
                else object.put("api_joke_status", "failure");

                // add the JSON object to the MongoDB collection
                MongoDBApp.insertMongoData(object.toString());

                String result = getData(pictureURL, joke,categories);
                request.setAttribute("result", result);

                System.out.println(MongoDBApp.printAllDocuments());

                nextView = "jokeType.jsp";
            }
            else {

                nextView = "prompt.jsp";
            }

        }
        else {
            // Retrieve all collection items and display them in a log table
            request.setAttribute("searchTermTable", MongoDBApp.printAllDocuments());
            request.setAttribute("topSearchTerms", MongoDBApp.topSearchTerms());
            request.setAttribute("dbSize", MongoDBApp.dbSize());
            request.setAttribute("avgFlickrLatency", MongoDBApp.avgFlickrLatency());
            nextView = "Dashboard.jsp";
        }

        RequestDispatcher view = request.getRequestDispatcher(nextView);
        view.forward(request, response);
    }

    static private String getData(String pictureURL, String joke, String catList) {
        JSONObject returnObject = new JSONObject();
        returnObject.put("pictureURL", pictureURL);
        returnObject.put("joke", joke);
        returnObject.put("categories",catList);
        return returnObject.toString();
    }


}
