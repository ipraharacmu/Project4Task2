//ipsita praharaj
//iprahara
package ds;

import com.mongodb.*;
import com.mongodb.client.*;
import com.mongodb.client.model.Sorts;
import org.bson.Document;
import org.json.JSONArray;
import org.json.JSONObject;

import java.util.*;
import java.util.stream.Collectors;

public class MongoDBApp {

    // Defining MongoDB connection parameters
    private static final String MONGODB_CONNECTION_STRING = "mongodb+srv://iprahara:nainy4ever@cluster0.cqsnoxf.mongodb.net/";
    private static final String DATABASE_NAME = "finalDatabase";
    private static final String COLLECTION_NAME = "my_collection";
    private static JSONArray allDocuments = new JSONArray();


    // Method for printing all documents in the MongoDB collection
    public static void insertMongoData(String inputString) {
        // Creating a connection string for MongoDB
        ConnectionString connectionString = new ConnectionString(MONGODB_CONNECTION_STRING);

        // Building MongoClient settings
        MongoClientSettings settings = MongoClientSettings.builder()
                .applyConnectionString(connectionString)
                .serverApi(ServerApi.builder()
                        .version(ServerApiVersion.V1)
                        .build())
                .build();

        // Creating a MongoClient instance
        MongoClient mongoClient = MongoClients.create(settings);

        // Accessing a database
        MongoDatabase database = mongoClient.getDatabase(DATABASE_NAME);

        // Accessing a collection
        MongoCollection<Document> collection = database.getCollection(COLLECTION_NAME);

        // Inserting a document into the collection
        Document document = Document.parse(inputString);
        collection.insertOne(document);

        String json = document.toJson();
        JSONObject jsonObject = new JSONObject(json);
        jsonObject.remove("_id"); // remove the "_id" field from the JSON object
        allDocuments.put(jsonObject);
        System.out.println(document.keySet() + "key ipsita");

    }

    public static String printAllDocuments() {
        StringBuilder htmlTable = new StringBuilder();
        htmlTable.append("<table style='border-collapse: collapse;'><tr>");

        // Add column headers
        JSONObject firstDoc = allDocuments.getJSONObject(0);
        Iterator<String> keys = firstDoc.keys();
        while (keys.hasNext()) {
            String key = keys.next();
            htmlTable.append("<th style='border: 1px solid black; padding: 8px;'>").append(key).append("</th>");
        }

        htmlTable.append("</tr>");

        // Add document rows
        for (int i = 0; i < allDocuments.length(); i++) {
            JSONObject doc = allDocuments.getJSONObject(i);
            htmlTable.append("<tr>");

            // Add values for each column
            keys = doc.keys();
            while (keys.hasNext()) {
                String key = keys.next();
                String value = doc.getString(key);
                htmlTable.append("<td style='border: 1px solid black; padding: 8px;'>").append(value).append("</td>");
            }

            htmlTable.append("</tr>");

            // Add a separating line after each row
            htmlTable.append("<tr><td colspan='" + firstDoc.length() + "' style='border-bottom: 1px solid red;'></td></tr>");
        }

        htmlTable.append("</table>");

        return htmlTable.toString();

    }

    public static String topSearchTerms() {
        if (allDocuments == null) {
            // If allDocuments is null, fetch all documents and store them in the static JSONArray
            return "nothing";
        }
        // Counting the frequency of each search term
        Map<String, Integer> termCount = new HashMap<>();
        for (int i = 0; i < allDocuments.length(); i++) {
            JSONObject jsonObject = allDocuments.getJSONObject(i);
            String searchTerm = jsonObject.getString("Request_searchWord");
            termCount.put(searchTerm, termCount.getOrDefault(searchTerm, 0) + 1);
        }

        // Sorting search terms by their frequency and selecting the top 10
        List<String> topTerms = termCount.entrySet().stream()
                .sorted(Map.Entry.<String, Integer>comparingByValue().reversed())
                .limit(10)
                .map(Map.Entry::getKey)
                .collect(Collectors.toList());

        // Returning the top 10 search terms as a string
        return "Top 10 search terms: " + String.join(", ", topTerms);
    }

    public static String dbSize() {
        if (allDocuments == null) {
            // If allDocuments is null, fetch all documents and store them in the static JSONArray
            return "0";
        }
        return "Number of terms searched: " + String.valueOf(allDocuments.length());
    }

    public static String avgFlickrLatency() {
        // Creating a connection string for MongoDB
        ConnectionString connectionString = new ConnectionString(MONGODB_CONNECTION_STRING);

        // Building MongoClient settings
        MongoClientSettings settings = MongoClientSettings.builder()
                .applyConnectionString(connectionString)
                .serverApi(ServerApi.builder()
                        .version(ServerApiVersion.V1)
                        .build())
                .build();

        // Creating a MongoClient instance
        MongoClient mongoClient = MongoClients.create(settings);

        // Accessing a database
        MongoDatabase database = mongoClient.getDatabase(DATABASE_NAME);

        // Accessing a collection
        MongoCollection<Document> collection = database.getCollection(COLLECTION_NAME);
        long totalLatency = 0;
        int count = 0;
        for (int i = 0; i < allDocuments.length(); i++) {
            JSONObject jsonObject = allDocuments.getJSONObject(i);
            if (jsonObject.has("api_timestamp") && jsonObject.has("Request_timestamp")) {
                long apiTime = new Date(jsonObject.getString("api_timestamp")).getTime();
                long requestTime = new Date(jsonObject.getString("Request_timestamp")).getTime();
                totalLatency += apiTime - requestTime;
                count++;
            }
        }

        // Calculating the average latency and returning it as a string
        if (count > 0) {
            long avgLatency = totalLatency / count;
            return "Average search latency: " + avgLatency + "ms";
        }
        else return "No API calls found.";
    }
}

