//ipsita praharaj
//iprahara
package edu.heinz.ds.androidinterestingpicture;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Build;
//import android.os.Build;
//import android.support.annotation.RequiresApi;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.w3c.dom.Document;
import org.xml.sax.InputSource;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;

/*
 * This app provides capabilities to search for joke from ChuckNoris APi and an image on Flickr.com given a search term.  The method "search" is the entry to the class.
 * Network operations cannot be done from the UI thread, therefore this class makes use of inner class BackgroundTask that will do the network
 * operations in a separate worker thread.  However, any UI updates should be done in the UI thread so avoid any synchronization problems.
 * onPostExecution runs in the UI thread, and it calls the ImageView pictureReady method to do the update.
 *
 * Method BackgroundTask.doInBackground( ) does the background work
 * Method BackgroundTask.onPostExecute( ) is called when the background work is
 *    done; it calls *back* to ip to report the results
 *
 */
public class Get_joke_picture {
    Joke_picture ip = null;   // for callback
    String searchTerm = null;       // search Flickr for this word
    Bitmap picture = null;
    String response = "";
    String joinedString = "";
    JSONObject jsonObject;
    JSONArray jsonArray;

    // search( )
    // Parameters:
    // String searchTerm: the thing to search for on flickr
    // Activity activity: the UI thread activity
    // InterestingPicture ip: the callback method's class; here, it will be ip.pictureReady( )
    public void search(String searchTerm, Activity activity, Joke_picture ip) {
        this.ip = ip;
        this.searchTerm = searchTerm;
        new BackgroundTask(activity).execute();
    }



    private class BackgroundTask {

        private Activity activity; // The UI thread

        public BackgroundTask(Activity activity) {
            this.activity = activity;
        }

        private void startBackground() {
            new Thread(new Runnable() {
                public void run() {
                    try {

                        URL url = new URL("https://ipraharacmu-fictional-umbrella-9p69p66969v3p79-8080.preview.app.github.dev/getAnInterestingPicture?searchWord="+searchTerm);
                        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                        conn.setRequestMethod("GET");

                        // Reading the response from the API endpoint and storing it in a StringBuilder
                        BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                        String inputLine;
                        StringBuilder response = new StringBuilder();
                        while ((inputLine = in.readLine()) != null) {
                            response.append(inputLine);
                        }
                        in.close();

                        // Parsing the response as a JSONObject and returning the random joke in the selected category
                        jsonObject = new JSONObject(response.toString());
                        String joke = jsonObject.getString("joke");
                        String pictureURL = jsonObject.getString("pictureURL");
                        System.out.println("joke: " + joke);
                        System.out.println("pic: " + pictureURL);

                    } catch (Exception e) {
                        System.out.printf(e +" - oops");
                    }

                    try {
                        doInBackground();
                    } catch (JSONException e) {
                        throw new RuntimeException(e);
                    }
                    // This is magic: activity should be set to MainActivity.this
                    //    then this method uses the UI thread
                    activity.runOnUiThread(new Runnable() {
                        public void run() {
                            try {
                                onPostExecute();
                            } catch (JSONException e) {
                                throw new RuntimeException(e);
                            }
                        }
                    });
                }
            }).start();
        }

        private void execute(){
            // There could be more setup here, which is why
            //    startBackground is not called directly
            startBackground();
        }

        // doInBackground( ) implements whatever you need to do on
        //    the background thread.
        // Implement this method to suit your needs
        private void doInBackground() throws JSONException {
            picture = search(searchTerm);
        }

        // onPostExecute( ) will run on the UI thread after the background
        //    thread completes.
        // Implement this method to suit your needs
        public void onPostExecute() throws JSONException {
            ip.pictureReady(picture);
            ip.jsonObj(jsonObject.getString("joke"),jsonObject.getString("categories"));
        }

        /*
         * Search my codespace url's response key for the pictureURL argument, and return a Bitmap that can be put in an ImageView
         */
        @Nullable
        public String parseImageUrl(String htmlContent) throws JSONException {
            if (jsonObject.getString("pictureURL") != null) {
                return jsonObject.getString("pictureURL");
            } else {
                return "https://live.staticflickr.com/1261/5110834170_0797f39278_m.jpg";
            }
        }
        private Bitmap search(String searchTerm) throws JSONException {
            String pictureURL = parseImageUrl(response);
            // At this point, we have the URL of the picture that resulted from the search.  Now load the image itself.
            try {
                URL u = new URL(pictureURL);
                // Debugging:
                //System.out.println(pictureURL);
                return getRemoteImage(u);
            } catch (Exception e) {
                e.printStackTrace();
                return null; // so compiler does not complain
            }

        }


        /*
         * Given a URL referring to an image, return a bitmap of that image
         */
        @RequiresApi(api = Build.VERSION_CODES.P)
        private Bitmap getRemoteImage(final URL url) {
            try {
                final URLConnection conn = url.openConnection();
                conn.connect();
                BufferedInputStream bis = new BufferedInputStream(conn.getInputStream());
                Bitmap bm = BitmapFactory.decodeStream(bis);
                return bm;
            } catch (IOException e) {
                e.printStackTrace();
                return null;
            }
        }
    }
}

